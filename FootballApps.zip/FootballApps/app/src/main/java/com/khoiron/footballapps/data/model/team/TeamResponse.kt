package com.khoiron.footballapps.data.model.team

/**
 * Created by Khoiron14 on 29/11/18.
 */
data class TeamResponse(val teams: List<Team>)