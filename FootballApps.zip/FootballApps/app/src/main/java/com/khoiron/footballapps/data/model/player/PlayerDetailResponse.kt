package com.khoiron.footballapps.data.model.player

/**
 * Created by Khoiron14 on 29/11/18.
 */
data class PlayerDetailResponse(val players: List<PlayerDetail>)