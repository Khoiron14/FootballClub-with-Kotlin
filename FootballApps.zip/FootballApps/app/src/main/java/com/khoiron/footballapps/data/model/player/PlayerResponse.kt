package com.khoiron.footballapps.data.model.player

/**
 * Created by Khoiron14 on 29/11/18.
 */
data class PlayerResponse(val player: List<Player>)