package com.khoiron.footballapps.data.model.event

/**
 * Created by Khoiron14 on 29/11/18.
 */
data class EventResponse(val events: List<Event>)