package com.khoiron.footballmatchschedule.data.model.event

/**
 * Created by Khoiron14 on 20/11/18.
 */
data class EventResponse (
    val events: List<Event>
)