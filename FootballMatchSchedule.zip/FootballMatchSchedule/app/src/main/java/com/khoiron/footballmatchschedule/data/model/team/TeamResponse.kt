package com.khoiron.footballmatchschedule.data.model.team

/**
 * Created by Khoiron14 on 22/11/18.
 */
data class TeamResponse (
    val teams: List<Team>
)