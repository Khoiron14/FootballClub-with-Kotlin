package com.khoiron.footballmatchschedule.data.model.eventdetail

/**
 * Created by Khoiron14 on 21/11/18.
 */
data class EventDetailResponse (
    val events: List<EventDetail>
)